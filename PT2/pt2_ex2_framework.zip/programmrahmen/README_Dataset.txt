The format is:
first_name,last_name,IBAN