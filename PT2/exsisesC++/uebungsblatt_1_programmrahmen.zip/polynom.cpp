#include <iostream>
#include <string>
#include <vector>

int polynom()
{
	// ToDo: Exercise 2.b - compute value of P(x)
	return 0;
}

void prettyPrint(double decimal)
{
	// ToDo: Exercise 2.c - print number with thousands separators to console

	std::cout << decimal;
}

int main(int argc, char* argv[])
{
	// ToDo: Exercise 2.a - read parameters and x, deal with invalid values

	// ToDo: Exercise 2.b - print P(x)
	// ToDo: Exercise 2.c - print P(x) with prettyPrint

	std::cout << "Hello World";

	return 0;
}
